<?php
// Exit if accessed directly
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Optionally delete options or data saved by the plugin
delete_option('wc_coupon_exporter_settings');
